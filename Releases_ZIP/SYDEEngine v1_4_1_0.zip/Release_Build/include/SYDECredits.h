#pragma once
#include <string>

using namespace std;
class SYDECredits {
public:
	static string _GAMETITLE;
	static string _ORGANISATION;
	static string _OTHERCREDITS;
};