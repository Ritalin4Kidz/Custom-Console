#pragma once
#include "SYDEOldCodeAI.h"
#include "SYDEOldCodeBoard.h"
#include "SYDEOldCodeBoardPiece.h"
#include "SYDEOldCodeCharacters.h"