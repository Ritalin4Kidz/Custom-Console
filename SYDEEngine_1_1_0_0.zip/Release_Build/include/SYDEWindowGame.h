#pragma once
#include "ConsoleWindow.h"
__interface SYDEWindowGame
{
	virtual ConsoleWindow window_draw_game(ConsoleWindow window, int windowWidth, int windowHeight) {}
};